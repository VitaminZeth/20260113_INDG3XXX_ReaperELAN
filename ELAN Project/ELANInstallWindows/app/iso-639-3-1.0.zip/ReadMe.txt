The ISO 639-3 set of code tables are provided by www.iso639-3.sil.org.
For the Terms of Use see:
https://iso639-3.sil.org/code_tables/download_tables#termsofuse

The table enclosed in this zip file is available over the direct link:
https://iso639-3.sil.org/sites/iso639-3/files/downloads/iso-639-3.tab